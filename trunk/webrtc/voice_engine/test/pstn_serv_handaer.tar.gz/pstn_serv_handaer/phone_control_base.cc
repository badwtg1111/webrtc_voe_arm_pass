/*
 * =====================================================================================
 *
 *       Filename:  phone_control_base.cc
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  05/03/2013 04:07:28 PM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <string.h>
#include <iostream>
using namespace std;

namespace handaer{
	

PhoneControlBase::PhoneControlBase()
	:serial_fd(-1),
	 msg(NULL),
	 msg_len(0),
	 time_out_ms(500){
	cout << "sizeof device_name = " << sizeof(device_name) << endl;
	memset(device_name, 0, sizeof(device_name));	
	memcpy(device_name, "/dev/ttySAC3", 13);

}
PhoneControlBase::~PhoneControlBase(){
}

int PhoneControlBase::setReadTimeOutMs(int time_out_ms_){
	time_out_ms = time_out_ms_;
	return 0;
}
int PhoneControlBase::setDeviceName(char *dev_name){
	memset(device_name, 0, sizeof(device_name));	
	memcpy(device_name, dev_name, strlen(dev_name)+1 ); 
	
	return 0;
}
int PhoneControlBase::openDevice(void){

	return 0;
}
int PhoneControlBase::serialConfig(speed_t baudrate);
int PhoneControlBase::closeDevice(int fd);

ssize_t PhoneControlBase::readOnce(int fd, char *buf, size_t len);
ssize_t PhoneControlBase::readAll(int fd, char *buf, size_t len);
ssize_t PhoneControlBase::writeDevice(int fd, const char *buf, size_t len);



}
