/*
 * =====================================================================================
 *
 *       Filename:  phone_control_base.h
 *
 *    Description:  finish the serial control  
 *
 *        Version:  1.0
 *        Created:  05/03/2013 04:07:19 PM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (chen.chunsheng badwtg1111@hotmail.com), 
 *   Organization:  handaer
 *
 * =====================================================================================
 */

namespace handaer{

class PhoneControlBase{
	public:
		PhoneControlBase();
		~PhoneControlBase();

		int setReadTimeOutMs(int time_out_ms_);
		int setDeviceName(char *dev_name);
		int openDevice(void);
		int serialConfig(speed_t baudrate);
		int closeDevice(int fd);
		
		ssize_t readAll(int fd, char *buf, size_t len);
		ssize_t writeDevice(int fd, const char *buf, size_t len);
	private:
		ssize_t readOnce(int fd, char *buf, size_t len);

		char device_name[16];
		int serial_fd;
		char * msg;
		int msg_len;
		int time_out_ms;
};



}
